from setuptools import setup, find_packages

setup(
    name='Automated_Test',
    version='1.03',
    packages=find_packages(),
    url='',
    license='',
    author='HeyNiu',
    author_email='',
    description='',
    install_requires=['requests', 'threadpool']
)

